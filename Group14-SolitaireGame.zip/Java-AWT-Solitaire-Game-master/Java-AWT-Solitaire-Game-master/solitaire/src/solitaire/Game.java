package solitaire;

public class Game {

	Engine game;
	GUI gui;
	
	public Game() {
		game = new Engine();
		gui = new GUI(game);
	}
	
	public static void main(String[] args) {
		@SuppressWarnings("unused")
		Game Solitaire = new Game();
	}
}
