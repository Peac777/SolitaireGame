package application.move;

public interface Move {
	
	void move();
}
