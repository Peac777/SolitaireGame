package application.move;

import application.model.GameModel;

public class DeckMove implements Move{
	
	GameModel gameModel;

	public DeckMove(GameModel gameModel) {
		this.gameModel = gameModel;
	}

	@Override
	public void move() {
		if(gameModel.discard()) {
			
		}
	}

}