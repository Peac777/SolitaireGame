package application.model;


import java.util.Stack;

import application.card.Card;
import application.card.Deck;
import application.move.DeckMove;
import application.move.Move;

public class GameModel {
	
	private static final GameModel INSTANCE = new GameModel();
	private Deck deck = new Deck();
	private Stack<Card> waste;
	
	public static GameModel getInstance() {
		return INSTANCE;
	}
	
	public Move getDeckMove() {
		return new DeckMove(getInstance());
	}
	
	public void reset() {
		deck.reset();
		waste = new Stack<Card>();
	}
	
	public boolean discard() {
		if(!this.deck.isEmpty()) {
			Card c = this.deck.draw();
			System.out.println(c);
			waste.add(c);
			return true;
		}
		
		return false;
	}
	
	
	
	
	
	
	

}