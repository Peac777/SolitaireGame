package application.model;

public interface GameModelListener {
	
	
	void gameStateChanged();
	

}
