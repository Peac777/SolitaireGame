package application;

import java.util.Map;
import java.util.HashMap;

import javafx.scene.image.Image;


public class CardImages {
	
	private static Map<String, Image> cards = new HashMap<String, Image>();
	
	private static final String IMAGE_LOCATION = "images/";
	
	private static final String IMAGE_SUFFUX = ".png";
	
	private static Image getImage(String code) {
		
		Image image = cards.get(code);
		
		if(image == null) {
			
			image = new Image(CardImages.class.getClassLoader() .getResourceAsStream(IMAGE_LOCATION + code + IMAGE_SUFFUX));
			cards.put(code, image);
		}
		
		return image;
		
	}
	
	public static Image getBack() {
		
		return getImage("background");
		
	}
	

}
