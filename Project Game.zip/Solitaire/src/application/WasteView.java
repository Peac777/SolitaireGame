package application;



import javafx.scene.layout.HBox;
import application.card.Card;
import application.model.GameModel;
import application.model.GameModelListener;
import javafx.geometry.Insets;
import javafx.scene.image.ImageView;







public class WasteView extends HBox implements GameModelListener{
	private static final int PADDING = 5;
	
	
	public WasteView () {
		
		setPadding(new Insets(PADDING));
		
		ImageView image = new ImageView(CardImages.getBack());
		image.setVisible(false);
		
		getChildren().add(image);
		GameModel.getInstance().addListener(this);
		
		
	}


	@Override
	public void gameStateChanged() {
		// TODO Auto-generated method stub
		
		/*System.out.println(this.getClass().getSimpleName());
		System.out.println(new Throwable()
				.getStackTrace()[0]
						.getMethodName());*/
		
		getChildren().get(0).setVisible(true);
		Card topCard = GameModel.getInstance().peekWaste();
		ImageView image = (ImageView) this.getChildren().get(0);
		
		image.setImage(CardImages.getImage(topCard));
		
		//System.out.println(CardImages.getCode(topCard));
	}
}

