package application.card;

public enum Suit {
	
	CLUBS, DIAMONDS, SPADES, HEARTS

}
